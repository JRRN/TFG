using EasyNetQ;
using uocrdle.stats.api.Configuration;
using uocrdle.stats.api.Data;
using uocrdle.stats.api.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var Configuration = builder.Configuration;

IBus bus;

RabbitMQConfiguration rabbitConfiguration = new RabbitMQConfiguration();

Configuration.GetSection("RabbitMQConnection").Bind(rabbitConfiguration);
var instrumentationKey = Configuration.GetValue<string>("ApplicationInsights:InstrumentationKey");

builder.Services.AddApplicationInsightsTelemetry(instrumentationKey);

bus = RabbitHutch.CreateBus(rabbitConfiguration.ConnectionString);
builder.Services.AddSingleton(bus);

bus.Advanced.QueueDeclare("stats");

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.Configure<MongoConnection>(Configuration.GetSection("MongoConnection"));
builder.Services.Configure<RabbitMQConfiguration>(Configuration.GetSection("RabbitMQConnection"));

builder.Services.AddScoped<IStatsRepository, StatsRepository>();
builder.Services.AddScoped<IStatsService, StatsService>();
builder.Services.AddScoped<IRabbitMqService, RabbitMqService>();

var app = builder.Build();


app.UseSwagger();
app.UseSwaggerUI();


app.UseCors(x => x.AllowAnyOrigin());
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
