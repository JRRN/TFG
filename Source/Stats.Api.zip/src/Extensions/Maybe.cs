﻿namespace uocrdle.stats.api.Extensions;

public class Maybe<T> : IMaybe<T>
{
    public static readonly Maybe<T> Nothing = new Maybe<T>();

    public bool HasValue { get; }

    public T Value { get; }

    private Maybe() { }

    public Maybe(T value)
    {
        HasValue = !Equals(value, null);
        Value = value;
    }

    public static implicit operator Maybe<T>(T value)
    {
        return new Maybe<T>(value);
    }
}

public interface IMaybe<out T>
{
    bool HasValue { get; }

    T Value { get; }
}