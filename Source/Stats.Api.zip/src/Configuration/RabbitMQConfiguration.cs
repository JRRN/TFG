﻿namespace uocrdle.stats.api.Configuration;

public class RabbitMQConfiguration
{
    public string ConnectionString { get; set; }
}