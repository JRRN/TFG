﻿namespace uocrdle.stats.api.Controllers.Models;

public class StatisticsModel
{
    public string Language { get; set; }
    public int FirstAttempt { get; set; }
    public int SecondAttempt { get; set; }
    public int ThirdAttempt { get; set; }
    public int FourthAttempt { get; set; }
    public int FifthAttempt { get; set; }
    public int SixtAttempt { get; set; }
}