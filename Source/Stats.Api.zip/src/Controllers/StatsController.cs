using Microsoft.AspNetCore.Mvc;
using System.Net.Mime;
using System.Security.Cryptography.Xml;
using EasyNetQ;
using uocrdle.stats.api.Controllers.Models;
using uocrdle.stats.api.Services;

namespace uocrdle.stats.api.Controllers
{
    [ApiController]
    [Route("api/stats")]
    [Produces(MediaTypeNames.Application.Json)]
    public class StatsController : ControllerBase
    {
        private readonly IStatsService _statsService;
        private readonly IRabbitMqService _rabbitMqService;
        private readonly ILogger<StatsController> _logger;
        private readonly List<string> _languages = new() { "es", "fr", "de", "en" };

        public StatsController(ILogger<StatsController> logger, IRabbitMqService rabbitMqService, IStatsService statsService)
        {
            _logger = logger;
            _rabbitMqService = rabbitMqService;
            _statsService = statsService;
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<StatisticsModel>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<IActionResult> GetStats(CancellationToken cancellationToken)
        {
            try
            {
                var collectionStats = new List<StatisticsModel>();

                foreach (var language in _languages)
                {
                    var statsInfo = await _statsService.GetAll(language, cancellationToken);
                    if (statsInfo.HasValue)
                    {
                        var one = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 5);
                        var two = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 4);
                        var three = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 3);
                        var four = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 2);
                        var five = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 1);
                        var six = statsInfo.Value.statInfo.FirstOrDefault(x => x.attempt == 6);

                        var statModel = new StatisticsModel
                        {
                            Language = statsInfo.Value.language,
                            FirstAttempt = one?.quantity ?? 0,
                            SecondAttempt = two?.quantity ?? 0,
                            ThirdAttempt = three?.quantity ?? 0,
                            FourthAttempt = four?.quantity ?? 0,
                            FifthAttempt = five?.quantity ?? 0,
                            SixtAttempt = six?.quantity ?? 0,
                        };
                        collectionStats.Add(statModel);
                    }
                    else
                    {
                        var statModel = new StatisticsModel
                        {
                            Language = language,
                            FirstAttempt = 0,
                            SecondAttempt = 0,
                            ThirdAttempt = 0,
                            FourthAttempt = 0,
                            FifthAttempt= 0,
                            SixtAttempt = 0

                        };
                        collectionStats.Add(statModel);
                    }
                }

                if (collectionStats.Any())
                {
                    return Ok(collectionStats);
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError("GetStats: ", ex);
                return BadRequest();
            }
        }


        [HttpPost]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> PostStats([FromQuery] string language, [FromQuery] int attempt, CancellationToken cancellationToken)
        {
            try
            {
                await _rabbitMqService.Publish(language, attempt, cancellationToken);
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError("PostStats: ", ex);
                return BadRequest(ex);
            }
        }
    }
}