﻿using uocrdle.stats.api.Data.Base;

namespace uocrdle.stats.api.Data.Model;

public class stats : BaseStatEntity
{
    
}