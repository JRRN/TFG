﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using uocrdle.stats.api.Configuration;
using uocrdle.stats.api.Data.Base;
using uocrdle.stats.api.Extensions;

namespace uocrdle.stats.api.Data;

public class StatsRepository : IStatsRepository
{
    private readonly MongoClient _client;
    private readonly IMongoDatabase _database;

    public StatsRepository(IOptions<MongoConnection> dbOptions)
    {
        IMongoClient client = new MongoClient(dbOptions.Value.ConnectionString);
        _database = client.GetDatabase(dbOptions.Value.DatabaseName);
    }

    public IMongoClient Client => _client;
    public IMongoDatabase Database => _database;

    public async Task<Model.stats> GetAll(string language, CancellationToken cancellationToken)
    {
        var collection = _database.GetCollection<BaseStatEntity>($"stats");
        var result = new Model.stats();
        using (IAsyncCursor<BaseStatEntity> cursor = await collection.FindAsync<BaseStatEntity>(x => x.language == language, cancellationToken: cancellationToken))
        {
            while (await cursor.MoveNextAsync(cancellationToken))
            {
                IEnumerable<BaseStatEntity> batch = cursor.Current;
                
                batch.ToList().ForEach(x => result = new Model.stats
                {
                    Id = x.Id,
                    language = language,
                    statInfo = x.statInfo
                });
            }
        }
        return result;
    }
}

public interface IStatsRepository
{
    Task<Model.stats> GetAll(string language, CancellationToken cancellationToken);
}