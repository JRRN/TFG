﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Collections.ObjectModel;

namespace uocrdle.stats.api.Data.Base;

public class BaseStatEntity
{
    [BsonId]        
    public ObjectId Id { get; set; }
    public string language { get; set; }
    public Collection<BaseStats> statInfo { get; set;}
}

public class BaseStats
{
    public int attempt { get; set; }
    public int quantity { get; set; }
}
