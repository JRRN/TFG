﻿using EasyNetQ;
using Microsoft.Extensions.Options;
using Shared.Models;
using uocrdle.stats.api.Configuration;

namespace uocrdle.stats.api.Services;

public class RabbitMqService : IRabbitMqService
{
    private readonly RabbitMQConfiguration _rabbitMqConnection;
    private readonly IBus _bus;

    public RabbitMqService(IOptions<RabbitMQConfiguration> rabbitMqConnection, IBus bus)
    {
        _bus = bus;
        _rabbitMqConnection = rabbitMqConnection.Value;
    }

    public async Task Publish(string language, int attempt, CancellationToken cancellationToken)
    {
        await _bus.SendReceive.SendAsync("stats", new StatsModel
        {
            Attempt = attempt,
            Language = language
        }, cancellationToken);

        Console.WriteLine("Message published!");
    }
}

public interface IRabbitMqService
{
    Task Publish(string language, int attempt, CancellationToken cancellationToken);
}