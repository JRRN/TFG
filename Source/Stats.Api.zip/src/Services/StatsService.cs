﻿using uocrdle.stats.api.Data;
using uocrdle.stats.api.Extensions;

namespace uocrdle.stats.api.Services;

public class StatsService : IStatsService
{
    private readonly IStatsRepository _repository;

    public StatsService(IStatsRepository repository)
    {
        _repository = repository;
    }

    public async Task<Maybe<Data.Model.stats>> GetAll(string language, CancellationToken cancellationToken)
    {
        var statsRepository = await _repository.GetAll(language.ToLowerInvariant(), cancellationToken);

        return statsRepository.language is null ? 
            Maybe<Data.Model.stats>.Nothing : 
            new Maybe<Data.Model.stats>(statsRepository);
    }
}

public interface IStatsService
{
    Task<Maybe<Data.Model.stats>> GetAll(string language, CancellationToken cancellationToken);
}