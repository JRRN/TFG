using System.Collections.ObjectModel;
using Shared.Models;
using uocrdle.stats.consumer.Data;
using uocrdle.stats.consumer.Data.Base;
using uocrdle.stats.consumer.Services;

namespace uocrdle.stats.consumer
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private readonly IRabbitMqService _rabbitMqService;
        private readonly IStatsRepository _mongoService;

        public Worker(ILogger<Worker> logger, IRabbitMqService rabbitMqService, IStatsRepository mongoService)
        {
            _logger = logger;
            _rabbitMqService = rabbitMqService;
            _mongoService = mongoService;
        }

        protected override async Task ExecuteAsync(CancellationToken cancellationToken)
        {
            try
            {
                while (!cancellationToken.IsCancellationRequested)
                {
                    _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
                    await Task.Delay(1000, cancellationToken);

                    var message = await _rabbitMqService.Receive(cancellationToken);

                    if (message != null)
                    {
                        var repositoryEntity =
                            await _mongoService.GetCollectionByLanguage(message.Language, cancellationToken);

                        if (repositoryEntity.language != null)
                        {
                            var collectionResult = MapFromMessageToCollection(message, repositoryEntity);
                            await _mongoService.UpdateCollectionByLanguage(collectionResult, cancellationToken);
                        }
                        else
                        {
                            var collectionResult = MapFromMessageToNullCollection(message);
                            await _mongoService.InsertCollectionByLanguage(collectionResult, cancellationToken);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Worker: ", ex);
            }
        }

        private Data.Model.stats MapFromMessageToCollection(StatsModel message, Data.Model.stats repositoryEntity)
        {
            bool changed = false;
            foreach (var stats in repositoryEntity.statInfo)
            {
                if (stats.attempt == message.Attempt)
                {
                    stats.quantity++;
                    changed = true;
                }
            }

            if (changed == false)
            {
                repositoryEntity.statInfo.Add(new BaseStats
                {
                    attempt = message.Attempt,
                    quantity = 1
                });
            }

            return repositoryEntity;


        }

        private Data.Model.stats MapFromMessageToNullCollection(StatsModel message)
        {
            var newRepositoryEntity = new Data.Model.stats
            {
                language = message.Language
            };

            newRepositoryEntity.statInfo = new Collection<BaseStats>
            {
                new BaseStats
                {
                    attempt = message.Attempt,
                    quantity = 1
                }
            };

            return newRepositoryEntity;
        }
    }
}