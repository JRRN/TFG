﻿namespace uocrdle.stats.consumer.Configuration;

public class RabbitMQConfiguration
{
    public string ConnectionString { get; set; }
}