using EasyNetQ;
using uocrdle.stats.consumer;
using uocrdle.stats.consumer.Configuration;
using uocrdle.stats.consumer.Data;
using uocrdle.stats.consumer.Services;

IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureAppConfiguration((hostContext, config) =>
    {
        config.AddJsonFile("appsettings.json", optional: true)
              .AddJsonFile("appsettings.Development.json", optional: true)
              .AddEnvironmentVariables();
    })
    .ConfigureServices((HostBuilder, services) =>
    {
        var Configuration = HostBuilder.Configuration;
        IBus bus;

        RabbitMQConfiguration rabbitConfiguration = new RabbitMQConfiguration();

        Configuration.GetSection("RabbitMQConnection").Bind(rabbitConfiguration);
        var instrumentationKey = Configuration.GetValue<string>("ApplicationInsights:InstrumentationKey");
        
        services.AddLogging();
        services.AddApplicationInsightsTelemetryWorkerService(instrumentationKey);

        bus = RabbitHutch.CreateBus(rabbitConfiguration.ConnectionString);
        services.AddSingleton(bus);

        bus.Advanced.QueueDeclare("stats");

        services.Configure<MongoConnection>(Configuration.GetSection("MongoConnection"));
        services.Configure<RabbitMQConfiguration>(Configuration.GetSection("RabbitMQConnection"));
        services.AddHealthChecks();
        services.AddHostedService<Worker>();
        services.AddSingleton<IRabbitMqService, RabbitMqService>();
        services.AddSingleton<IStatsRepository, StatsRepository>();
    })
    .Build();

await host.RunAsync();
