﻿using System.Text;
using EasyNetQ;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Shared.Models;
using uocrdle.stats.consumer.Configuration;

namespace uocrdle.stats.consumer.Services;

public class RabbitMqService : IRabbitMqService
{
    private readonly RabbitMQConfiguration _rabbitMqConnection;
    private readonly IBus _bus;
    public RabbitMqService(IOptions<RabbitMQConfiguration> rabbitMqConnection, IBus bus)
    {
        _bus = bus;
        _rabbitMqConnection = rabbitMqConnection.Value;
    }
    public async Task<StatsModel> Receive(CancellationToken cancellationToken)
    {
        var result = new StatsModel();

        var existingQueue = new EasyNetQ.Topology.Queue("stats", false);

        var consumer = _bus.Advanced.CreatePullingConsumer(existingQueue, true);
        var pullBatchAsync = await consumer.PullBatchAsync(1, cancellationToken);
        
        var message = pullBatchAsync.Messages.FirstOrDefault();
        if (message.IsAvailable)
        {
            var body = Encoding.UTF8.GetString(message.Body);
            result = JsonConvert.DeserializeObject<StatsModel>(body);
            return result;
        }

        return null;
    }
}



public interface IRabbitMqService
{
    Task<StatsModel> Receive(CancellationToken cancellationToken);
}

