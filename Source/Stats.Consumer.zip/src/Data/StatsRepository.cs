﻿using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using uocrdle.stats.consumer.Configuration;
using uocrdle.stats.consumer.Data.Base;

namespace uocrdle.stats.consumer.Data;

public class StatsRepository : IStatsRepository
{
    private readonly MongoClient _client;
    private readonly IMongoDatabase _database;

    public StatsRepository(IOptions<MongoConnection> dbOptions)
    {
        _client = new MongoClient(dbOptions.Value.ConnectionString);
        _database = _client.GetDatabase(dbOptions.Value.DatabaseName);
    }

    public async Task<Model.stats> GetCollectionByLanguage(string language, CancellationToken cancellationToken)
    {
        var collection = _database.GetCollection<BaseStatEntity>($"stats");
        var result = new Model.stats();
        using (IAsyncCursor<BaseStatEntity> cursor = await collection.FindAsync<BaseStatEntity>(x => x.language == language, cancellationToken: cancellationToken))
        {
            while (await cursor.MoveNextAsync(cancellationToken))
            {
                IEnumerable<BaseStatEntity> batch = cursor.Current;

                batch.ToList().ForEach(x => result = new Model.stats
                {
                    Id = x.Id,
                    language = language,
                    statInfo = x.statInfo
                });
            }
        }
        return result;
    }

    public async Task UpdateCollectionByLanguage(Model.stats modelCollection, CancellationToken cancellationToken)
    {
        var collection = _database.GetCollection<BaseStatEntity>($"stats");
        var filter = Builders<BaseStatEntity>.Filter.Eq("language", modelCollection.language);
        await collection.DeleteOneAsync(filter, cancellationToken);

        await InsertCollectionByLanguage(modelCollection, cancellationToken);
    }

    public async Task InsertCollectionByLanguage(Model.stats modelCollection, CancellationToken cancellationToken)
    {
            var collection = _database.GetCollection<BaseStatEntity>($"stats");
            var options = new InsertOneOptions
            {
                BypassDocumentValidation = true
            };
            await collection.InsertOneAsync(modelCollection, options, cancellationToken);
    }
}

public interface IStatsRepository
{
    Task<Model.stats> GetCollectionByLanguage(string language, CancellationToken cancellationToken);
    Task UpdateCollectionByLanguage(Model.stats collection, CancellationToken cancellationToken);
    Task InsertCollectionByLanguage(Model.stats collection, CancellationToken cancellationToken);
}