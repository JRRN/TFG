﻿using uocrdle.stats.consumer.Data.Base;

namespace uocrdle.stats.consumer.Data.Model;

public class stats : BaseStatEntity
{
    
}