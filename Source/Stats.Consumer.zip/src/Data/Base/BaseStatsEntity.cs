﻿using System.Collections.ObjectModel;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace uocrdle.stats.consumer.Data.Base;

public class BaseStatEntity
{
    [BsonId]        
    public ObjectId Id { get; set; }
    public string language { get; set; }
    public Collection<BaseStats> statInfo { get; set;}
}

public class BaseStats
{
    public int attempt { get; set; }
    public int quantity { get; set; }
}
