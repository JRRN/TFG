﻿namespace Shared.Models
{
    public class StatsModel
    {
        public string Language { get; set; }
        public int Attempt { get; set; }
    }
}