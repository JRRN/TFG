# Presentation: 

### NodeJS Front Application

- #### Without Docker

	```sh
	- ..\TFG\Presentation\src> npm start
	- Open browser: http://localhost:8500
	```

- #### With Docker

	```sh
	- ..\TFG\Presentation\docker> docker-compose up app
	- Open browser: http://localhost:8600
	```