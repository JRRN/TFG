'use strict';
const { json } = require('body-parser');
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    res.render('index', { title: 'UOCRDLE' });
});


router.get('/stats', function (req, res) {
    res.render('stats', { title: 'UOCRDLE' });
});

router.get("/config", function (req, res) {
    console.log(process.env.NODE_ENV);

    if(process.env.NODE_ENV === undefined){
        res.json ({ urlwords: "https://localhost:7170", urlstats: "https://localhost:7209" }); 
    }

    if (process.env.NODE_ENV === "production") {
        res.json(
            {
                urlwords: "https://localhost:9800",
                urlstats: "https://localhost:10800"
            }
        );
    }
    if (process.env.NODE_ENV === "DockerAzure") {
        res.json(
            {
                urlwords: "https://uocrdle-words-api-as-dev.azurewebsites.net",
                urlstats: "https://uocrdle-stats-api-as-dev.azurewebsites.net"
            }
        );
    }

    if (process.env.NODE_ENV === "k8s") {
        res.json(
            {
                urlwords: "http://localhost:30164",
                urlstats: "http://localhost:31000"
            }
        );
    }
    
});

module.exports = router;
