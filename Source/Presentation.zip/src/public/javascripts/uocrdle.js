const numberOfGuesses = 6;
var guessesRemaining = 6;
var currentGuess = [];
var nextLetter = 0;
var rightGuessString = "";
var WORDS = [];
var config = {};


async function initGame() {
    try {
        var res = await fetch("/config");
        if (res.status === 200) {
            config = await res.json();
            console.log(config);

            var lang = getCookieLanguage("language");
            var response = await fetch(`${config.urlwords}/api/words?language=${lang}`);

            if (response.status === 200) {
                WORDS = await response.json();
                rightGuessString = WORDS[0];
                console.log(rightGuessString);
            } else if (response.status === 204) {
                alert("Error-HTTP: No Content ");
            }
        }

    } catch (error) {
        alert("Error-HTTP: " + error);
    }
}

function initBoard() {
    let board = document.getElementById("game-board");

    for (let i = 0; i < numberOfGuesses; i++) {
        let row = document.createElement("div");
        row.className = "letter-row";

        for (let j = 0; j < 5; j++) {
            let box = document.createElement("div");
            box.className = "letter-box";
            row.appendChild(box);
        }

        board.appendChild(row);
    }
}

function shadeKeyBoard(letter, color) {
    for (const elem of document.getElementsByClassName("keyboard-button")) {
        if (elem.textContent === letter) {
            let oldColor = elem.style.backgroundColor;
            if (oldColor === '#008000') {
                return;
            }
            if (oldColor === '#c9b458' && color !== '#008000') {
                return;
            }
            elem.style.backgroundColor = color;
            break;
        }
    }
}

function deleteLetter() {
    let row = document.getElementsByClassName("letter-row")[6 - guessesRemaining];
    let box = row.children[nextLetter - 1];
    box.textContent = "";
    box.classList.remove("filled-box");
    currentGuess.pop();
    nextLetter -= 1;
}

async function checkGuess() {
    var row = document.getElementsByClassName("letter-row")[6 - guessesRemaining];
    var guessString = '';
    var rightGuess = Array.from(rightGuessString);

    for (const val of currentGuess) {
        guessString += val;
    }

    if (guessString.length != 5) {
        toastr.error("Not enough letters!");
        return;
    }
    var lang = getCookieLanguage("language");
    var responseCheck = await fetch(`${config.urlwords}/api/words?language=${lang}&wordInput=${guessString}`);
    if (responseCheck.status === 200) {
        for (let i = 0; i < 5; i++) {
            let letterColor = '';
            let box = row.children[i];
            let letter = currentGuess[i];

            let letterPosition = rightGuess.indexOf(currentGuess[i].toUpperCase());
            if (letterPosition === -1) {
                //gris
                letterColor = '#787c7e';
            } else {
                if (currentGuess[i].toUpperCase() === rightGuess[i].toUpperCase()) {
                    //verde
                    letterColor = '#008000';
                } else {
                    //amarillo
                    letterColor = '#c9b458';
                }

                rightGuess[letterPosition] = "#";
            }

            let delay = 250 * i;
            setTimeout(() => {
                animateCSS(box, 'flipInX');
                box.style.backgroundColor = letterColor;
                box.style.color = '#FFFFFF';
                shadeKeyBoard(letter, letterColor);
            }, delay);
        }
        if (guessString.toUpperCase() === rightGuessString.toUpperCase()) {
            toastr.success("You guessed right! Game over!");
            postStat(guessesRemaining);
            guessesRemaining = 0;
            return;
        } else {
            guessesRemaining -= 1;
            currentGuess = [];
            nextLetter = 0;

            if (guessesRemaining === 0) {
                postStat(guessesRemaining);
                toastr.error("You've run out of guesses! Game over!");
                toastr.info(`The right word was: "${rightGuessString}"`);
            }

        }
    } else if (responseCheck.status === 204) {
        toastr.error("Word not in dictionary!");
        return;
    } else {
        toastr.error("Error!");
        return;
    }
}

async function postStat(currentGuess) {

    var lang = getCookieLanguage("language");
    const otherParams = {
        method: "POST"
    };
    await fetch(`${config.urlstats}/api/stats?language=${lang}&attempt=${currentGuess}`, otherParams);
}


function insertLetter(pressedKey) {
    if (nextLetter === 5) {
        return;
    }
    pressedKey = pressedKey.toLowerCase();

    let row = document.getElementsByClassName("letter-row")[6 - guessesRemaining];
    let box = row.children[nextLetter];
    animateCSS(box, "pulse");
    box.textContent = pressedKey;
    box.classList.add("filled-box");
    currentGuess.push(pressedKey);
    nextLetter += 1;
}

const animateCSS = (element, animation, prefix = 'animate__') =>
    new Promise((resolve, reject) => {
        const animationName = `${prefix}${animation}`;
        const node = element;
        node.style.setProperty('--animate-duration', '0.3s');

        node.classList.add(`${prefix}animated`, animationName);

        function handleAnimationEnd(event) {
            event.stopPropagation();
            node.classList.remove(`${prefix}animated`, animationName);
            resolve('Animation ended');
        }

        node.addEventListener('animationend', handleAnimationEnd, { once: true });
    });

document.addEventListener("keyup", (e) => {
    if (guessesRemaining === 0) {
        return;
    }

    let pressedKey = String(e.key);
    if (pressedKey === "Backspace" && nextLetter !== 0) {
        deleteLetter();
        return;
    }

    if (pressedKey === "Enter") {
        checkGuess();
        return;
    }

    let found = pressedKey.match(/[a-z\u00f1]/gi);
    if (!found || found.length > 1) {
        return;
    } else {
        insertLetter(pressedKey);
    }
});

document.getElementById("keyboard-cont").addEventListener("click", (e) => {
    const target = e.target;

    if (!target.classList.contains("keyboard-button")) {
        return;
    }
    let key = target.textContent;

    if (key === "Del") {
        key = "Backspace";
    }
    document.dispatchEvent(new KeyboardEvent("keyup", { 'key': key }));
});

const gamestatsbtn = document.getElementById('gamestats');
gamestatsbtn.addEventListener('click', async function (e) {
    try {
        var response = await fetch(`${config.urlstats}/api/stats`);
        if (response.status === 200) {
            var stats = await response.json();

            var newHtml = document.createElement("div");
            newHtml.id = 'statsm';
            newHtml.InnerHTML = "";
            stats.forEach(el => {
                newHtml.InnerHTML += (
                    '<ul class="list-group"> ' +
                    '<li class="list-group-item"> ' + el.language.toUpperCase() + '</li>' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 1: <span class="badge bg-primary rounded-pill">' + el.firstAttempt + '</span> </li>   ' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 2: <span class="badge bg-primary rounded-pill">' + el.secondAttempt + '</span> </li>   ' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 3: <span class="badge bg-primary rounded-pill">' + el.thirdAttempt + ' </span></li>   ' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 4: <span class="badge bg-primary rounded-pill">' + el.fourthAttempt + '</span> </li>   ' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 5: <span class="badge bg-primary rounded-pill">' + el.fifthAttempt + '</span></li>   ' +
                    '<li class="list-group-item d-flex justify-content-between align-items-center"style="font-size: 17px;">Intento 5: <span class="badge bg-primary rounded-pill">' + el.sixtAttempt + '</span></li>   ' +
                    '</ul><br>'
                );
            });
            var modal_content = document.getElementById('statsm');
            modal_content.innerHTML = newHtml.InnerHTML;
            modalstats.style.display = "block";
        }
        if (response.status === 204) {
            toastr.error("No stats yet!");
            return;
        }
    } catch (error) {
        alert("Error-HTTP: " + error);
    }
});


const gameinfobtn = document.getElementById('gameinfo');
gameinfobtn.addEventListener('click', function (e) {
    modalgameinfo.style.display = "block";
});

const gamesettingsbtn = document.getElementById('gamesettings');
gamesettingsbtn.addEventListener('click', function (e) {
    modallanguages.style.display = "block";
});

//Modals
var modalgameinfo = document.getElementById('modalgameinfo');
var spangameinfo = document.getElementById('closegameinfo');

var modallanguages = document.getElementById('modallanguages');
var spanlanagues = document.getElementById('closelanguagemodal');

var modalstats = document.getElementById('modalstats');
var spanstats = document.getElementById('closestatsmodal');

spanlanagues.onclick = function () {
    modallanguages.style.display = "none";
}

spanstats.onclick = function () {
    modalstats.style.display = "none";
}

spangameinfo.onclick = function () {
    modalgameinfo.style.display = "none";
}

window.onclick = function (event) {
    if (event.target === modallanguages) {
        modallanguages.style.display = "none";
    }
    if (event.target === modalstats) {
        modalstats.style.display = "none";
    }
    if (event.target === modalgameinfo) {
        modalgameinfo.style.display = "none";
    }
}

setLanguage.addEventListener('click', function (e) {
    var languageSelected = document.querySelector('input[name="languageradio"]:checked').value;
    setCookieLanguage(languageSelected);
    modallanguages.style.display = "none";
    location.reload();
});

function getCookieLanguage(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts[1] === "" || parts.length === 1) {
        setCookieLanguage("es");
        return "es";
    }
    if (parts.length === 2) return parts.pop().split(';').shift();
}

function setCookieLanguage(value) {
    document.cookie = 'language=' + value;
}

initBoard();
initGame();