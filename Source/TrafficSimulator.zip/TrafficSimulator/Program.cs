﻿// See https://aka.ms/new-console-template for more information


using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;using NBomber.CSharp;
using TrafficSimulator.Abstractions;


using IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices((_, services) =>
        services.AddSingleton<IBomberExtension>(x => new BomberExtension()))
    .Build();


await Simulate(host.Services);
await host.RunAsync();


static async Task Simulate(IServiceProvider services)
{
    using IServiceScope serviceScope = services.CreateScope();
    IServiceProvider provider = serviceScope.ServiceProvider;

    var bomber = provider.GetRequiredService<IBomberExtension>();

    var wordScenario = await bomber.SimulateWords();
    var statsScenario =  await bomber.SimulateStats();

    bomber.ExecuteScenarios(wordScenario, statsScenario);
}