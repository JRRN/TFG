﻿using Microsoft.AspNetCore.WebUtilities;
using NBomber.Contracts;
using NBomber.CSharp;
using Newtonsoft.Json;
using System.Text;

namespace TrafficSimulator.Abstractions;

public interface IBomberExtension
{
    public Task<Scenario> SimulateWords();
    public Task<Scenario> SimulateStats();
    void ExecuteScenarios(Scenario words, Scenario stats);
}

public class BomberExtension : IBomberExtension
{
    private readonly HttpClient _httpclient;

    public BomberExtension()
    {
        _httpclient = new HttpClient();
    }

    public async Task<Scenario> SimulateWords()
    {
        
        var get = Step.Create("Get", async context =>
        {
            var lang = GetRandLang();
            using var request =
                new HttpRequestMessage(HttpMethod.Get, "http://localhost:30164/api/words")
                    .AddQueryParam("language", lang);

            //Console.WriteLine(request.RequestUri);
            var response = await _httpclient.SendAsync(request);

            return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
        });

        var check = Step.Create("check", async context =>
        {
            var validWord = String.Empty;
            var lang = GetRandLang();
            validWord = GetValidWord(lang);

            using var request =
                new HttpRequestMessage(HttpMethod.Get, "http://localhost:30164/api/words/check")
                    .AddQueryParam("language", lang)
                    .AddQueryParam("wordInput", validWord);

            //Console.WriteLine(request.RequestUri);
            var response = await _httpclient.SendAsync(request);

            return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
        });

        var scenario = ScenarioBuilder.CreateScenario("Words", get, check);
        scenario.WithLoadSimulations(Simulation.KeepConstant(100000, TimeSpan.FromSeconds(60)));

        return scenario;
    }
    
    public async Task<Scenario> SimulateStats()
    {
        var get = Step.Create("Get", async context =>
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:31000/api/stats");
            
            var response = await _httpclient.SendAsync(request);
            return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();

        });

        var put = Step.Create("Post", async context =>
        {
            using var request =
                new HttpRequestMessage(HttpMethod.Post, "http://localhost:31000/api/stats")
                    .AddQueryParam("language", GetRandLang())
                    .AddQueryParam("attempt", new Random().Next(6).ToString());
            
            var response = await _httpclient.SendAsync(request);

            return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
        });

        var scenario = ScenarioBuilder.CreateScenario("Stats", get, put);
        scenario.WithLoadSimulations(Simulation.KeepConstant(100000, TimeSpan.FromSeconds(60)));

        return scenario;
    }

    private static string GetValidWord(string lang)
    {
        string validWord;
        string words = lang switch
        {
            "es" => DictionariesString.GetDictionaryStringES(),
            "de" => DictionariesString.GetDictionaryStringDE(),
            "fr" => DictionariesString.GetDictionaryStringFR(),
            _ => DictionariesString.GetDictionaryStringEN()
        };

        var splitedStringWord = words.Split(",");

        var rand = new Random().Next(splitedStringWord.Length - 1);
        validWord =  splitedStringWord[rand];
        return validWord;
    }
    
    private static string GetRandLang()
    {
        var numlanguages = new Random().Next(3);
        return numlanguages switch
        {
            0 => "es",
            1 => "de",
            2 => "fr",
            _ => "en"
        };
    }

    public void ExecuteScenarios(Scenario words, Scenario stats)
    {
        NBomberRunner
            .RegisterScenarios(words, stats)
            .Run();
    }
}

public static class Extensions
{
    public static HttpRequestMessage SerializeJsonContent<T>(this HttpRequestMessage httpRequestMessage, T o)
    {
        httpRequestMessage.Content = (HttpContent)new StringContent(JsonConvert.SerializeObject((object)o), Encoding.UTF8, "application/json");
        return httpRequestMessage;
    }

    public static HttpRequestMessage AddQueryParam(
        this HttpRequestMessage httpRequestMessage,
        string key,
        string value)
    {
        string uriString = QueryHelpers.AddQueryString(httpRequestMessage.RequestUri.ToString(), key, value);
        httpRequestMessage.RequestUri = new Uri(uriString, UriKind.RelativeOrAbsolute);
        return httpRequestMessage;
    }

}



