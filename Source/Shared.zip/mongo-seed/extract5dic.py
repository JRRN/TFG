import array as arr
import os

languages = ['es','fr','de','en']

for lang in languages:
   fileToRemove = 'words_{}.csv'.format(lang)
   if os.path.exists(fileToRemove):
    os.remove(fileToRemove) 

for lang in languages:
    dic = open("dic.{}.txt".format(lang), "r",encoding='utf8')

    outputfile = open('words_{}.csv'.format(lang), 'a',encoding='utf8')
    outputfile.write('word\n')
    outputfile.close()

    while(True):
        myline = dic.readline()
        
        if not myline:
                break

        if(len(myline) == 6):
            outputfile = open('words_{}.csv'.format(lang), 'a',encoding='utf8')
            outputfile.write(myline.upper())
            outputfile.close()
    dic.close()

