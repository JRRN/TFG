﻿using System.Net.Mime;
using Microsoft.AspNetCore.Mvc;
using uocrdle.words.api.Services;

namespace uocrdle.words.api.Controllers
{
    [ApiController]
    [Route("api/words")]
    [Produces(MediaTypeNames.Application.Json)]
    public class WordsController : Controller
    {
        private readonly IWordsService _service;
        private readonly ILogger<WordsController> _logger;

        public WordsController(IWordsService service, ILogger<WordsController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> GetWords(string language, CancellationToken cancellationToken)
        {
            try
            {
                var words = await _service.GetAll(language, cancellationToken);

                if (words.Any())
                {
                    return Ok(words);
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetWords {language}", ex);
                return BadRequest();
            }
        }

        [HttpGet("check")]
        [ProducesResponseType(typeof(List<string>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Check(string language, string wordInput, CancellationToken cancellationToken)
        {
            try
            {


                var words = await _service.CheckWordSolution(language, wordInput.ToUpperInvariant(), cancellationToken);

                if (words != null)
                {
                    return Ok(words);
                }

                return NoContent();
            }
            catch (Exception ex)
            {
                _logger.LogError($"GetWords {language}", ex);
                return BadRequest();
            }
        }
    }
}
