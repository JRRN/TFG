using uocrdle.words.api.Configuration;
using uocrdle.words.api.Data;
using uocrdle.words.api.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

var Configuration = builder.Configuration;
var instrumentationKey = Configuration.GetValue<string>("ApplicationInsights:InstrumentationKey");

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddApplicationInsightsTelemetry(instrumentationKey);

var mongoConnection = new MongoConnection();
Configuration.GetSection("MongoConnection").Bind(mongoConnection);

builder.Services.Configure<MongoConnection>(Configuration.GetSection("MongoConnection"));

builder.Services.AddScoped<IWordsRepository, WordsRepository>();
builder.Services.AddScoped<IWordsService, WordsService>();

var app = builder.Build();

if (app.Environment.EnvironmentName == "DockerDemo")
{
    var init = new InitializeDB(mongoConnection);
    await init.InitMongoDBAsync();
}

// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI();


app.UseCors(x => x.AllowAnyOrigin());
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
