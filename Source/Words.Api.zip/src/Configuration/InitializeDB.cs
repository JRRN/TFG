﻿using MongoDB.Driver;
using uocrdle.words.api.Configuration.Files;
using uocrdle.words.api.Data;
using uocrdle.words.api.Data.Base;

namespace uocrdle.words.api.Configuration;

public class InitializeDB
{
    private readonly IMongoClient _client;
    private readonly IMongoDatabase _database;
    private readonly IWordsRepository _wordsRepository;
    private readonly List<string> languages = new(){"es", "de", "en", "fr"};

    public InitializeDB(MongoConnection dbOptions)
    {
        _wordsRepository = new WordsRepository(dbOptions);
        _client= new MongoClient(dbOptions.ConnectionString);
        _database = _client.GetDatabase(dbOptions.DatabaseName);
    }

    public async Task InitMongoDBAsync()
    {
        foreach (var language in languages)
        {
            var result = await _wordsRepository.GetAll(language, CancellationToken.None);

            if (result.Count == 0)
            {
                var resourceWors = GetResourceByLanguage(language);

                var splitedStringWord = resourceWors.Split(",");

                var collectionWords = splitedStringWord.Select(x => new BaseWordEntity
                {
                    word = x
                });

                var collection = _database.GetCollection<BaseWordEntity>($"words_{language}");
                var options = new InsertManyOptions
                {
                    BypassDocumentValidation = true
                };
                await collection.InsertManyAsync(collectionWords, options, CancellationToken.None);
            }
        }
    }

    private string GetResourceByLanguage(string language)
    {
        return language switch
        {
            "en" => DictionariesString.GetDictionaryStringEN(),
            "de" => DictionariesString.GetDictionaryStringDE(),
            "fr" => DictionariesString.GetDictionaryStringFR(),
            _ => DictionariesString.GetDictionaryStringES()
        };
    }
}