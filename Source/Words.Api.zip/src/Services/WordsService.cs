﻿using uocrdle.words.api.Data;

namespace uocrdle.words.api.Services;

public class WordsService : IWordsService
{
    private readonly IWordsRepository _repository;

    public WordsService(IWordsRepository repository)
    {
        _repository = repository;
    }

    public async Task<List<string>> GetAll(string language, CancellationToken cancellationToken)
    {
        var result = new List<string>();
        var wordsRepository = await _repository.GetAll(language.ToLowerInvariant(), cancellationToken);

        var onlyWords = wordsRepository.Select(x => x.word).ToList();

        string gameWord = String.Empty;

        while (string.IsNullOrEmpty(gameWord))
        {
            var selectedPosition = CalculateSelectedPosition(onlyWords);
            gameWord = GetGameWord(onlyWords, selectedPosition);
        }

        result.Add(gameWord);
        return result;
    }

    public async Task<string> CheckWordSolution(string language, string wordInput, CancellationToken cancellationToken)
    {
        
        var wordsRepository = await _repository.Find(language.ToLowerInvariant(), wordInput.ToUpperInvariant(), cancellationToken);
        
        return wordsRepository.Select(x => x.word).FirstOrDefault();
        
    }

    private static string GetGameWord(List<string> onlyWords, int selectedPosition)
    {
        var gameWord = onlyWords.ElementAt(selectedPosition);
        return gameWord;
    }

    private static int CalculateSelectedPosition(List<string> onlyWords)
    {
        var rand = new decimal(new Random().NextDouble());
        var randomDecimal = Math.Floor(rand * onlyWords.Count);
        var selectedPosition = Decimal.ToInt32(randomDecimal);
        return selectedPosition;
    }
}

public interface IWordsService
{
    Task<List<string>> GetAll(string language, CancellationToken cancellationToken);
    Task<string> CheckWordSolution(string language, string wordInput, CancellationToken cancellationToken);
}