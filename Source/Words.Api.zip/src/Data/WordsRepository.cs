﻿using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System.Collections.ObjectModel;
using uocrdle.words.api.Configuration;
using uocrdle.words.api.Data.Base;

namespace uocrdle.words.api.Data;

public class WordsRepository : IWordsRepository
{
    private readonly MongoClient _client;
    private readonly IMongoDatabase _database;

    public WordsRepository(IOptions<MongoConnection> dbOptions)
    {
        IMongoClient client = new MongoClient(dbOptions.Value.ConnectionString);
        _database = client.GetDatabase(dbOptions.Value.DatabaseName);
    }

    public WordsRepository(MongoConnection dbOptions)
    {
        IMongoClient client = new MongoClient(dbOptions.ConnectionString);
        _database = client.GetDatabase(dbOptions.DatabaseName);
    }

    
    public IMongoClient Client => _client;
    public IMongoDatabase Database => _database;

    public async Task<Collection<Models.words>> GetAll(string language, CancellationToken cancellationToken)
    {
        var collection = _database.GetCollection<BaseWordEntity>($"words_{language}");
        var result = new Collection<Models.words>();
        using (IAsyncCursor<BaseWordEntity> cursor = await collection.FindAsync<BaseWordEntity>(new BsonDocument(), cancellationToken: cancellationToken))
        {
            while (await cursor.MoveNextAsync(cancellationToken))
            {
                IEnumerable<BaseWordEntity> batch = cursor.Current;
                
                batch.ToList().ForEach(x => result.Add(new Models.words
                {
                    Id = x.Id,
                    word = x.word
                }));
            }
        }
        return result;
    }

    public async Task<Collection<Models.words>> Find(string language, string wordInput, CancellationToken cancellationToken)
    {
        var collection = _database.GetCollection<BaseWordEntity>($"words_{language}");
        var result = new Collection<Models.words>();

        using (IAsyncCursor<BaseWordEntity> cursor = await collection.FindAsync<BaseWordEntity>(x => x.word == wordInput, cancellationToken: cancellationToken))
        {
            while (await cursor.MoveNextAsync(cancellationToken))
            {
                IEnumerable<BaseWordEntity> batch = cursor.Current;
                
                batch.ToList().ForEach(x => result.Add(new Models.words
                {
                    Id = x.Id,
                    word = x.word
                }));
            }
        }
        //TODO Collection Too Big Return Play Word Only
        return result;
    }
}

public interface IWordsRepository : IRepository<Models.words>
{
    Task<Collection<Models.words>> GetAll(string language, CancellationToken cancellationToken);
    Task<Collection<Models.words>> Find(string language, string wordInput, CancellationToken cancellationToken);
}

