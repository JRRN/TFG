﻿using System.Collections.ObjectModel;

namespace uocrdle.words.api.Data.Base;

public interface IRepository<T> where T : class
{
    Task<Collection<T>> GetAll(string language, CancellationToken cancellationToken);

}