﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace uocrdle.words.api.Data.Base;

public class BaseWordEntity
{
    [BsonId]        
    public ObjectId Id { get; set; }
    public string word { get; set; }
}
