﻿using uocrdle.words.api.Data.Base;

namespace uocrdle.words.api.Data.Models;

public class words : BaseWordEntity
{
    
}